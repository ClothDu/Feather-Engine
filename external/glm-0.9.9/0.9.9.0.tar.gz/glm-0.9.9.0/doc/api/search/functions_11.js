var searchData=
[
  ['tan',['tan',['../a00240.html#ga293a34cfb9f0115cc606b4a97c84f11f',1,'glm']]],
  ['tanh',['tanh',['../a00240.html#gaa1bccbfdcbe40ed2ffcddc2aa8bfd0f1',1,'glm']]],
  ['third',['third',['../a00157.html#ga3077c6311010a214b69ddc8214ec13b5',1,'glm']]],
  ['three_5fover_5ftwo_5fpi',['three_over_two_pi',['../a00157.html#gae94950df74b0ce382b1fc1d978ef7394',1,'glm']]],
  ['to_5fstring',['to_string',['../a00227.html#ga8f0dced1fd45e67e2d77e80ab93c7af5',1,'glm']]],
  ['tomat3',['toMat3',['../a00219.html#ga433955cb703d982427fb53b540d02f3d',1,'glm']]],
  ['tomat4',['toMat4',['../a00219.html#ga1fa0fb798c2715148e2e0358442bf895',1,'glm']]],
  ['toquat',['toQuat',['../a00219.html#gae9be791077b7a612d9092a922bd13f86',1,'glm::toQuat(mat&lt; 3, 3, T, Q &gt; const &amp;x)'],['../a00219.html#ga6c0a178ac9c7d23e1a6848045d83aa54',1,'glm::toQuat(mat&lt; 4, 4, T, Q &gt; const &amp;x)']]],
  ['translate',['translate',['../a00163.html#ga1a4ecc4ad82652b8fb14dcb087879284',1,'glm::translate(mat&lt; 4, 4, T, Q &gt; const &amp;m, vec&lt; 3, T, Q &gt; const &amp;v)'],['../a00208.html#gaf4573ae47c80938aa9053ef6a33755ab',1,'glm::translate(mat&lt; 3, 3, T, Q &gt; const &amp;m, vec&lt; 2, T, Q &gt; const &amp;v)'],['../a00229.html#ga309a30e652e58c396e2c3d4db3ee7658',1,'glm::translate(vec&lt; 3, T, Q &gt; const &amp;v)']]],
  ['transpose',['transpose',['../a00238.html#gae679d841da8ce9dbcc6c2d454f15bc35',1,'glm']]],
  ['trianglenormal',['triangleNormal',['../a00211.html#gaff1cb5496925dfa7962df457772a7f35',1,'glm']]],
  ['trunc',['trunc',['../a00143.html#gaf9375e3e06173271d49e6ffa3a334259',1,'glm']]],
  ['tweakedinfiniteperspective',['tweakedInfinitePerspective',['../a00163.html#gaaeacc04a2a6f4b18c5899d37e7bb3ef9',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near)'],['../a00163.html#gaf5b3c85ff6737030a1d2214474ffa7a8',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near, T ep)']]],
  ['two_5fover_5fpi',['two_over_pi',['../a00157.html#ga74eadc8a211253079683219a3ea0462a',1,'glm']]],
  ['two_5fover_5froot_5fpi',['two_over_root_pi',['../a00157.html#ga5827301817640843cf02026a8d493894',1,'glm']]],
  ['two_5fpi',['two_pi',['../a00157.html#gaa5276a4617566abcfe49286f40e3a256',1,'glm']]],
  ['two_5fthirds',['two_thirds',['../a00157.html#ga9b4d2f4322edcf63a6737b92a29dd1f5',1,'glm']]]
];
