var searchData=
[
  ['value_5fptr',['value_ptr',['../a00172.html#ga1c64669e1ba1160ad9386e43dc57569a',1,'glm']]]
];
